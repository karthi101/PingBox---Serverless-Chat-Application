import boto3
import json
import uuid
from datetime import datetime
import os

dynamodb = boto3.resource('dynamodb')
connections_table = dynamodb.Table('ChatConnections')
messages_table = dynamodb.Table('ChatMessages')

APIGW_ENDPOINT = os.environ.get('APIGW_ENDPOINT', 'https://Replace ur Websocket url with https.amazonaws.com/')

def post_to_connection(client, connection_id, data):
    try:
        client.post_to_connection(ConnectionId=connection_id, Data=data)
        return True
    except client.exceptions.GoneException:
        print(f"Connection {connection_id} gone. Removing.")
        return False
    except Exception as e:
        print(f"Error posting to {connection_id}: {e}")
        return False

def lambda_handler(event, context):
    print("Received event:", json.dumps(event))

    try:
        body = json.loads(event.get('body') or '{}')
    except Exception as e:
        print("Body parse error:", e)
        body = {}

    message = body.get('message')
    sender = body.get('sender', 'Anonymous')
    timestamp = body.get('timestamp') or datetime.utcnow().isoformat()

    if not message:
        return {'statusCode': 400, 'body': 'No message provided'}

    msg_id = str(uuid.uuid4())
    messages_table.put_item(Item={
        'MessageID': msg_id,
        'Sender': sender,
        'Message': message,
        'Timestamp': timestamp
    })

    apigw = boto3.client('apigatewaymanagementapi', endpoint_url=APIGW_ENDPOINT)
    conns = connections_table.scan(ProjectionExpression='ConnectionID').get('Items', [])

    print(f"Found {len(conns)} connections")

    payload = json.dumps({'sender': sender, 'message': message, 'timestamp': timestamp}).encode('utf-8')

    for c in conns:
        cid = c['ConnectionID']
        success = post_to_connection(apigw, cid, payload)
        if not success:
            connections_table.delete_item(Key={'ConnectionID': cid})

    return {'statusCode': 200, 'body': 'Message sent'}
